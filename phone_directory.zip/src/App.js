
import './App.css';
import Header from './components/Header';
import ContactList from './components/ContactList';
import {React} from 'react';
import AddContact from './components/AddContact';

function App() {
 let headerTitle='Phone Directory';

function clickHandler(event){
  console.log("Hi");
  console.log(event)
}

  return (
    <>
      <Header title={headerTitle} subHeading='Upgrad'  >TESTING</Header>
      <AddContact data='test data'/>
      <ContactList  onButtonClick={clickHandler} />
      
      {/* <Header title='PCO' /> */}
      

    </>
    
  );
}

export default App;
