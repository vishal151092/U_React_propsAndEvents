

export default function UserDataRow(props){

    function deleteActionHandler(){
        console.log(props.contact.id);
        props.onDelete(props.contact.id);
    }
return(
    <div className='data-container'>
                            <span >{props.contact.name}</span><span>{props.contact.phone}</span>
                            <button onClick={deleteActionHandler} className='delete-btn'>Delete</button>
                        </div>
)

}