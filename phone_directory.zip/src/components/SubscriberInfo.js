import UserDataRow from "./UserDataRow";


export default function SubscriberInfo(props){

    function onDelteHandler(event){
        console.log(event);
        props.onContactDelete(event);
    }

    function contactListCreator(){
        return props.contactData.map((data,index)=> {
            return <UserDataRow key={index} contact={data}  onDelete={onDelteHandler} />
                
        }); 
    }
    return(
        <div>

            
        {contactListCreator()}
        </div>
    )
}