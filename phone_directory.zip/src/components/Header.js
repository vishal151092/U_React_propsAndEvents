import './Header.css';

export default function Header(props){
    //let headerText = 'Phone Directory';
    console.log(props);
     function headerStyle() {
        return{
            color : 'white',
            fontSize: 'bold'
        }
        
    }
    return (
        <header style={headerStyle()} className="header" >
            {props.children}
             {props.title.toUpperCase()} -
            <span>{props.subHeading}</span></header>
        
    );
}



